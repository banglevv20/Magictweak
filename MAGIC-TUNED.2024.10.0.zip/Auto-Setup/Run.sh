echo "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
sleep 1
				echo "Fitur ini masih Tahap proses"
	sleep 1
echo "Dukungan Dari Kalian, Sangat di butuhkan"
		sleep 1
echo "Silahkan, Tekan Tombol Subscribe Untuk Info Update"
sleep 1
			echo "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
		echo ""
		
	sleep 1
	
	echo "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
	sleep 1
				echo "This feature is still under construction"
	sleep 1
		echo "Your support is really needed"
			sleep 1
	echo "Please, Tap Subscribe Button For Information"
		sleep 2
		1
		echo "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
		sleep 2
am start -a android.intent.action.VIEW -d https://www.youtube.com/c/BANGLEvV
exit
