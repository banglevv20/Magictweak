input text 'Wow, it so cool feature'
# <?command version=[1.0] encording=[utf-8]?>
value=$null
name=$banglevv
	echo "This Files Copyright (c) 2023 Bang Levv,"
	sleep 2
		echo""
		
	echo "LEGACY, all rights reversed"
	sleep 2
	echo ""
	
echo "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
echo "WAITING ANDROID OPTIMIZER UNINSTALLER"
   sleep 3

for app in $(pm list packages -3 | cut -f 2 -d ":"); do
echo "revert ART Compiler $app"
cmd package compile -m verify -f $app 2>&1 >/dev/null
done

(
device_config delete game_overlay com.mobile.legends
device_config delete game_overlay com.garena.game.codm
device_config delete game_overlay com.dts.freefiremax
device_config delete game_overlay com.dts.freefireth
device_config delete game_overlay com.miHoYo.GenshinImpact
device_config delete game_overlay com.tencent.ig
device_config delete game_overlay com.pubg.newstate
device_config delete game_overlay com.ea.gp.apexlegendsmobilefps
device_config delete game_overlay com.shooter.modernWarships
device_config delete game_overlay com.carxtech.sr
device_config delete game_overlay com.pubg.imobile
device_config delete game_overlay com.pubg.krmobile
device_config delete game_overlay com.HoYoverse.hkrpgoversea
device_config delete game_overlay com.roblox.client
device_config delete game_overlay com.ngame.allstar.eu
device_config delete game_overlay com.garena.game.lmjx
device_config delete game_overlay com.miHoYo.bh3global
device_config delete game_overlay com.epicgames.fortnite
device_config delete game_overlay com.minecraftpe.minecraft.original.free
device_config delete game_overlay com.proximabeta.mf.uamo
device_config delete game_overlay net.wargaming.wot.blitz
device_config delete game_overlay com.mobilelegends.hwag
device_config delete game_overlay com.ea.gp.fifamobile
device_config delete game_overlay com.gameloft.android.ANMP.GloftA8HM
device_config delete game_overlay com.igg.android.vikingriseglobal
device_config delete game_overlay com.axlebolt.standoff2
device_config delete game_overlay com.kurogame.gplay.punishing.grayraven.en
device_config delete game_overlay com.kakaogames.gdts
device_config delete game_overlay com.netease.newspike
device_config delete game_overlay jp.konami.pesam
)> /dev/null 2>&1
echo "deleted config game dashboard"
sleep 1

sf=$(dumpsys SurfaceFlinger)
fps=$(echo "$sf" | awk '/refresh-rate/ { gsub(/[^0-9.]+/, "", $3); printf("%.0f\n", $3) }')
for app in $(pm list packages -3 | cut -f 2 -d ":"); do
echo "config disable $app"
device_config delete game_overlay $app 2>&1 >/dev/null
device_config get game_overlay $app 2>&1 >/dev/null
echo "game mode balance default $app"
cmd game mode standard $app 2>&1 >/dev/null
done

# Internet Tweaks Uninstaller.
settings delete global private_dns_specifier
settings put global private_dns_mode opportunistic
echo "deleted internet Speed Tweaks"
sleep 1

# C++ display Uninstaller
wm density reset
settings delete global game_driver_all_apps
settings delete secure game_auto_temperature
settings delete secure game_dashboard_always_on
echo "Screen Resolution Changed"
sleep 1

# CODE
# Peak Refresh rate System Settings For 60HZ and Up.
# this code make Your devices got 60FPS in Games.
settings put system peak_refresh_rate 60
settings put system min_refresh_rate 60
settings put system user_refresh_rate 60
echo "Revert Default 60Hz+ Screen Refresh Rate"
sleep 1

settings delete global activity_manager_constants
echo "revert cached processes"
sleep 1

# Turn off all scrolling animations on user interface < 1.0=default >
settings put global animator_duration_scale 1.0
settings put global transition_animation_scale 1.0
settings put global window_animation_scale 1.0
echo "revert UI Tweaks"
sleep 1

echo "revert background"
settings put global app_standby_enabled 1
sleep 1

# reboot devices
echo "deleted Gpu Performance Tuner"
sleep 1

# reboot devices
echo "revert Tweaks Properties"
sleep 1

settings put system pointer_speed 4
echo "revert touch Speed"
sleep 1

for item in `dumpsys deviceidle whitelist`
do
app=`echo "$item" | cut -f2 -d ','`
#echo "deviceidle whitelist -$app"
dumpsys deviceidle whitelist -$app 2>&1 >/dev/null
am set-inactive $app true 2>&1 >/dev/null
		done
dumpsys deviceidle unforce
dumpsys battery reset
settings delete global battery_tip_constans
echo "revert GMS Doze"
sleep 1

      settings delete global power_check_max_cpu_1
      settings delete global power_check_max_cpu_2
      settings delete global power_check_max_cpu_3
      settings delete global power_check_max_cpu_4
	  echo "revert Power Check Max CPU"
sleep 1

device_config put activity_manager_native_boot use_freezer false
settings put global cached_apps_freezer 0
echo "revert Apps Cached"
sleep 1

settings put global always_finish_activities 0
echo "revert multitasking mode"
sleep 1

settings delete secure game_auto_tempature
settings delete system rakuten_denwa
settings delete system send_security_reports
settings delete global sem_enhanced_cpu_responsiveness
settings delete global enhanced_processing
settings delete system multicore_packet_scheduler
settings put global cached_apps_freezer disable
settings delete system mcf_continuity
echo "delete Advanced Performance Tweaks"
sleep 1

cmd thermalservice override-status 1
echo "revert Thermal"
sleep 1

cmd power set-fixed-performance-mode-enabled false
echo "removed performance mode"
sleep 1

# auto enabled
echo "revert Background"
sleep 1

echo "all magic tweak removed"
sleep 1
echo ""
echo ""
echo "✅🅿🅻🅴🅰🆂🅴 🆃🅰🅺🅴 🆂🆄🅱🆂🅲🆁🅸🅱🅴 & 🅻🅸🅺🅴"
sleep 5

	am start -a android.intent.action.VIEW -d https://www.youtube.com/c/BANGLEvV
# powered by bang levv