#!/system/bin/sh

#checking for all tweak installed on your devices
#checking_config
device_config get game_overlay com.ea.gp.apexlegendsmobilefps
device_config get game_overlay com.mobile.legends
device_config get game_overlay com.garena.game.codm
device_config get game_overlay com.dts.freefiremax
device_config get game_overlay com.dts.freefireth
device_config get game_overlay com.miHoYo.GenshinImpact
device_config get game_overlay com.tencent.ig
device_config get game_overlay com.pubg.newstate
device_config get game_overlay com.shooter.modernWarships
device_config get game_overlay com.carxtech.sr
device_config get game_overlay com.pubg.imobile
device_config get game_overlay com.pubg.krmobile
device_config get game_overlay com.HoYoverse.hkrpgoversea
device_config get game_overlay com.roblox.client
device_config get game_overlay com.ngame.allstar.eu
device_config get game_overlay com.garena.game.lmjx
device_config get game_overlay com.miHoYo.bh3global
device_config get game_overlay com.epicgames.fortnite
device_config get game_overlay com.minecraftpe.minecraft.original.free
device_config get game_overlay com.proximabeta.mf.uamo
device_config get game_overlay net.wargaming.wot.blitz
device_config get game_overlay com.mobilelegends.hwag
device_config get game_overlay com.ea.gp.fifamobile
device_config get game_overlay com.gameloft.android.ANMP.GloftA8HM
device_config get game_overlay com.igg.android.vikingriseglobal
device_config get game_overlay com.axlebolt.standoff2
device_config get game_overlay com.kurogame.gplay.punishing.grayraven.en
device_config get game_overlay com.kakaogames.gdts
device_config get game_overlay com.netease.newspike
device_config get game_overlay jp.konami.pesam
echo ""
sleep 2
for app in $(pm list packages -3 | cut -f 2 -d ":"); do
echo "config checking 3rd by $app"
device_config get game_overlay $app 2>&1 >/dev/null
done
echo ""
sleep 2

	echo "DATE :🕗 [$(date)]"
	echo "Powered by bang levv"
	exit