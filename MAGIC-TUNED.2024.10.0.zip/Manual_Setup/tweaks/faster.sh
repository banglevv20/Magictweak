input text 'Wow, it so cool feature'
# <?command version=[1.0] encording=[utf-8]?>
value=$null
name=$banglevv
	echo "This Files Copyright (c) 2023 Bang Levv,"
	echo "LEGACY, all rights reversed"
	sleep 2
	echo ""
	
echo "DEVICES INFORMATION"
sleep 2
echo "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
sleep 1
   echo " device model    : $(getprop ro.product.model)"
sleep 1
   echo " codename model  : $(getprop ro.build.product)"
sleep 1
   echo " device brand    : $(getprop ro.product.brand)"
sleep 1
echo "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
echo "WAITING ANDROID OPTIMIZER"
   sleep 3
echo ""
settings put global activity_manager_constants max_cached_processes 64
echo "Max Cached 64kbps"
sleep 1

# Turn off all scrolling animations on user interface < 1.0=default >
settings put global animator_duration_scale 0.0
settings put global transition_animation_scale 0.0
settings put global window_animation_scale 0.0
echo "forced UI Tweaks"
sleep 1

settings put global app_standby_enabled 0
echo "disable background"
sleep 1

setprop debug.composition.type gpu
setprop debug.composition.type c2d
setprop debug.hwui.renderer skiagl
setprop debug.gr.swapinterval 60
setprop debug.gr.numframebuffers 3
setprop debug.egl.buffcount 4
setprop debug.egl.force_msaa 1
setprop debug.egl.swapinterval 1
setprop debug.egl.hw 1
setprop debug.cpurend.vsync false
setprop debug.enabletr true
setprop debug.gralloc.gfx_ubwc_disable 0
setprop debug.mdpcomp.logs 0
setprop debug.performance.tuning 1
setprop debug.sf.hw 1
setprop debug.renderengine.backend skiagl
setprop debug.renderengine.backend vulkanthreaded
setprop debug.angle.overlay FPS:skiagl*PipelineCache*
setprop debug.javafx.animation.framerate 120
setprop debug.systemuicompilerfilter speed
setprop debug.app.performance_restricted false
setprop debug.enable-vr-mode 1
setprop debug.force-opengl 1
setprop debug.hwc.force_gpu_vsync 1
setprop debug.performance.profile 1
echo "Gpu Performance Tuner"
sleep 1

setprop debug.sf.set_idle_timer_ms 30
setprop debug.sf.disable_backpressure 1
setprop debug.sf.latch_unsignaled 1
setprop debug.sf.enable_hwc_vds 1
setprop debug.sf.early_phase_offset_ns 500000
setprop debug.sf.early_app_phase_offset_ns 500000
setprop debug.sf.early_gl_phase_offset_ns 3000000
setprop debug.sf.early_gl_app_phase_offset_ns 15000000
setprop debug.sf.high_fps_early_phase_offset_ns 6100000
setprop debug.sf.high_fps_late_sf_phase_offset_ns 8000000
setprop debug.sf.high_fps_early_gl_phase_offset_ns 9000000
setprop debug.sf.high_fps_late_app_phase_offset_ns 1000000
setprop debug.sf.high_fps_late_sf_phase_offset_ns 8000000
setprop debug.sf.high_fps_early_gl_phase_offset_ns 9000000
setprop debug.sf.phase_offset_threshold_for_next_vsync_ns 6100000
setprop debug.sf.showfps 0
setprop debug.sf.showcpu 0
setprop debug.sf.showbackground 0
setprop debug.sf.shoupdates 0
echo "additional Tweaks Properties"
sleep 1

settings put system pointer_speed 7
echo "improvement touch Speed"
sleep 1

for item in `dumpsys deviceidle whitelist`
do
app=`echo "$item" | cut -f2 -d ','`
#echo "deviceidle whitelist -$app"
dumpsys deviceidle whitelist +$app 2>&1 >/dev/null
am set-inactive $app false 2>&1 >/dev/null
		done
dumpsys deviceidle enable
dumpsys deviceidle force-idle
settings put global battery_tip_constans app_restriction_enabled false
echo "GMS Doze Custom"
sleep 1

      settings put global power_check_max_cpu_1 75
      settings put global power_check_max_cpu_2 75
      settings put global power_check_max_cpu_3 50
      settings put global power_check_max_cpu_4 50
	  echo "Power Check Max CPU"
sleep 1

device_config put activity_manager_native_boot use_freezer true
settings put global cached_apps_freezer 1
echo "freeze Apps Cached"
sleep 1


settings put global always_finish_activities 1
echo "disable multitasking"
sleep 1

settings put secure game_auto_tempature 0
settings put system rakuten_denwa 0
settings put system send_security_reports 0
settings put global sem_enhanced_cpu_responsiveness 1
settings put global enhanced_processing 2
settings put system multicore_packet_scheduler 1
settings put global cached_apps_freezer enabled
settings put system mcf_continuity 0
echo "Enabled Advanced Performance Tweaks"
sleep 1

cmd thermalservice override-status 0
echo "Disabled Thermal"
sleep 1

cmd power set-fixed-performance-mode-enabled true
echo "Enabled performance mode"
sleep 1

am kill-all
echo "closed Background"
sleep 1

echo "all magic tweak actived"
sleep 1
echo ""
echo "✅🅿🅻🅴🅰🆂🅴 🆃🅰🅺🅴 🆂🆄🅱🆂🅲🆁🅸🅱🅴 & 🅻🅸🅺🅴"
sleep 5

	am start -a android.intent.action.VIEW -d https://www.youtube.com/c/BANGLEvV
# powered by bang levv