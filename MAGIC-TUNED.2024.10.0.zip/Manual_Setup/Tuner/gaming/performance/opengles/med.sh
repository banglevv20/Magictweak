echo " DISCLAIMER :			"
echo " CONFIG GAME DASHBOARD WITHOUT BAN "
sleep 2
echo " UNLOCKING FPS WITH SCREEN HZ "
sleep 2
echo " SOFTWARE RENDERER "
sleep 2
echo " GAME PERFORMANCE ENHANCEMENT "
sleep 2
echo " GIVE US 1 GLASSES OF COFFEE "

echo ""
	sleep 4
echo "# GAME : MOBILE		"
	sleep 1
echo "# UID  : MAGIC TWEAKS	"
	sleep 1
echo "# DEV  : BANG LEVV	"
	sleep 1
echo ""
##################################
    # Justmode=2,opengles=1,downscaleFactor=0.9,fps=60:mode=3,opengles=0,downscaleFactor=0.9,fps=60Inmode=2,opengles=1,downscaleFactor=0.9,fps=60:mode=3,opengles=0,downscaleFactor=0.9,fps=60Time (JIT) compiler is a component of the runtime environment that improves the performance of Java™ applications by compiling bytecodes to native machine code at run time.
    # JIT supports android devices running on android 9 up to the latest version.
sf=$(dumpsys SurfaceFlinger)
fps=$(echo "$sf" | awk '/refresh-rate/ { gsub(/[^0-9.]+/, "", $3); printf("%.0f\n", $3) }')
for app in $(pm list packages -3 | cut -f 2 -d ":"); do
echo "Game Dashboard enable by $app"
device_config put game_overlay "$app" mode=2,opengles=1,downscaleFactor=0.7,fps=$fps:mode=3,opengles=0,downscaleFactor=0.7,fps=$fps
device_config get game_overlay "$app"
echo "performance mode On $app"
cmd game mode performance "$app"
echo "Android Runtime Compiled $app"
cmd package compile -m speed -f "$app"
done
echo "CODES ON THIS DEVICES"
getprop | grep -E 'debug\.' | grep -v 'persist' | sed 's/\[//g' | sed 's/\]//g' | sed 's/\://g' | sed 's/^/setprop /'
##################################
# $ New Tweak
##################################
    sleep 1
cat /proc/meminfo
