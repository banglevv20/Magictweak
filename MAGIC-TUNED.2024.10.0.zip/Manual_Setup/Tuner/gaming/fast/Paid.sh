echo "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
				echo "file ini khusus pengguna vip,"
	sleep 1
echo "anda tidak bisa menggunakan nya."
		sleep 1
echo "silahkan gabung membership channel atau akses sociabuzz"
			sleep 1
echo "untuk mendapatkan magic vip."
	sleep 1
		echo "admin : berry20.ea@gmail.com"
			sleep 2
			echo "▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒▒"
		echo ""
	echo ""
				echo "This file is specifically for VIP users,"
	sleep 1
		echo "you cannot use it."
			sleep 1
	echo "Please join the channel membership or access Sociabuzz to get Magic VIP."
		sleep 2
am start -a android.intent.action.VIEW -d https://m.youtube.com/channel/UCHepqylvjYSUcoxwu75uCmg/join
exit
