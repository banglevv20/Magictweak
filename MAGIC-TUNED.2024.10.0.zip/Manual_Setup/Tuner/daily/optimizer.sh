# DISCLAIMER:
# No one will be responsible for any problem MAGIC TWEAK™ may cause to you. Proceed With Caution !
#(By Installing MAGIC TWEAKS™, You Have Agreed To This)
###################################
# do not change, edit, delete or add code outside of this tweak code because there will be a risk of errors and boot failure.
###################################
# UID    :MAGIC_TWEAK
# DEV    :BANGLEVV

echo ""
echo "# NAME :DAILY USE		"
				sleep 1
echo "# UID  :MAGIC TWEAKS	"
				sleep 1
echo "# DEV  :BANGLEVV		"
				sleep 1
##################################
    # AOT compilation means Ahead of Time compilation. Again, as the . dex contain the bytecode, it needs to be translated to the machine code to be run. In ART Android Runtime, as it is AOT based, it gets translated before we run the app.

    # AOT supports android devices running on android 9 up to the latest version.
	echo " Waiting For Several Minutes"
cmd package bg-dexopt-job
				sleep 1
cat /proc/meminfo
