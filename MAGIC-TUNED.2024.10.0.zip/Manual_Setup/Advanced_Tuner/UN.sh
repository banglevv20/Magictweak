input text 'Wow, it so cool feature'
sleep 1
echo "Your Running Advanced Uninstaller"
sleep 1
echo "please wait for seferal second"
sleep 3
echo ""

#CODE
for app in $(pm list packages -3 | cut -f 2 -d ":"); do
echo "Advanced Tuner Disabled By $app"
dumpsys deviceidle whitelist -$app 2>&1 >/dev/null
done

#CODE
# Peak Refresh rate System Settings For 60HZ and Up.
# this code make Your devices got 60FPS in Games.
settings put system peak_refresh_rate 60
settings put system min_refresh_rate 60
settings put system user_refresh_rate 60
echo "Revert Default 60Hz+ Screen Refresh Rate"
sleep 1

echo "Don't use it daily because it can drain the battery"
# @banglevv
