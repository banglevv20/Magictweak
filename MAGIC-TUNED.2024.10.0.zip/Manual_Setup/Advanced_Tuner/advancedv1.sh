input text 'Wow, it so cool feature'
sleep 1
echo "Your Running Advanced V1"
sleep 1
echo "please wait for seferal second"
sleep 3
echo ""

#CODE
dumpsys deviceidle whitelist +com.miHoYo.GenshinImpact
dumpsys deviceidle whitelist +com.mobile.legends
dumpsys deviceidle whitelist +com.garena.game.codm
dumpsys deviceidle whitelist +com.dts.freefiremax
dumpsys deviceidle whitelist +com.dts.freefireth
dumpsys deviceidle whitelist +com.tencent.ig
dumpsys deviceidle whitelist +com.pubg.newstate
dumpsys deviceidle whitelist +com.ea.gp.apexlegendsmobilefps
dumpsys deviceidle whitelist +com.shooter.modernWarships
dumpsys deviceidle whitelist +com.carxtech.sr
dumpsys deviceidle whitelist +com.pubg.imobile
dumpsys deviceidle whitelist +com.pubg.krmobile
dumpsys deviceidle whitelist +com.HoYoverse.hkrpgoversea
dumpsys deviceidle whitelist +com.roblox.client
dumpsys deviceidle whitelist +com.ngame.allstar.eu
dumpsys deviceidle whitelist +com.garena.game.lmjx
dumpsys deviceidle whitelist +com.miHoYo.bh3global
dumpsys deviceidle whitelist +com.epicgames.fortnite
dumpsys deviceidle whitelist +com.minecraftpe.minecraft.original.free
dumpsys deviceidle whitelist +com.proximabeta.mf.uamo
dumpsys deviceidle whitelist +net.wargaming.wot.blitz
dumpsys deviceidle whitelist +com.mobilelegends.hwag
dumpsys deviceidle whitelist +com.ea.gp.fifamobile
dumpsys deviceidle whitelist +com.gameloft.android.ANMP.GloftA8HM
dumpsys deviceidle whitelist +com.igg.android.vikingriseglobal
dumpsys deviceidle whitelist +com.axlebolt.standoff2
dumpsys deviceidle whitelist +com.kurogame.gplay.punishing.grayraven.en
dumpsys deviceidle whitelist +com.kakaogames.gdts
dumpsys deviceidle whitelist +com.netease.newspike
dumpsys deviceidle whitelist +jp.konami.pesam
echo "Advanced Tuner Actived"
sleep 1
echo ""

#CODE
# Peak Refresh rate System Settings For 60HZ and Up.
# this code make Your devices got 60FPS in Games.
settings put system peak_refresh_rate 120
settings put system min_refresh_rate 60
settings put system user_refresh_rate 120
echo "Enabled 120FPS For 60Hz+ Screen Refresh Rate"
sleep 1


echo "Don't use it daily because it can drain the battery"
# @banglevv
