# android network code
############################################
# Brevent Flash Script (updater-script)
############################################
# this code uses default DNS hostname code according to the device provider. Don't use this code if your device provider doesn't support it.
echo "This code uses HOSTNAME PRIVATE DNS,"
sleep 1
echo "purpose of this code is to change the network"
sleep 1
echo "and block some advertisements on the site."
sleep 1
echo "Do not use this code if your device provider does not support it."
sleep 1
#_____________________________________________________________________________________
echo "waiting change..."
sleep 4
settings delete global private_dns_specifier

settings put global private_dns_mode opportunistic
echo "DONE"
exit 0
